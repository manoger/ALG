﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace ALGSolutions
{
    public partial class cadastro : System.Web.UI.Page
    { 
        protected void Page_Load(object sender, EventArgs e)
        {
            msgAviso.Text = "";
            txtConfirmacao.BorderColor = System.Drawing.Color.White;
        }

        protected void TextBtn_Click(object sender, EventArgs e)
        {
            msgAviso.Text = "";
            char[] caracteresInvalidos = "'$%&*><;:?]{}[ªº°".ToCharArray();
            if (string.IsNullOrWhiteSpace(txtEmail.Text) || string.IsNullOrWhiteSpace(txtNome.Text) || string.IsNullOrWhiteSpace(txtSenha.Text) || string.IsNullOrWhiteSpace(txtConfirmacao.Text))
            {
                msgAviso.Text = ("Preencha todos os campos</br>");
            }else
            if (txtEmail.Text.IndexOfAny(caracteresInvalidos)>0|| txtSenha.Text.IndexOfAny(caracteresInvalidos) > 0|| txtNome.Text.IndexOfAny(caracteresInvalidos) > 0|| txtConfirmacao.Text.IndexOfAny(caracteresInvalidos) > 0)
            {
                msgAviso.Text = "Caracteres inválidos";
            }else
            if (txtSenha.Text.Length < 8)
            {
                msgAviso.Text = ("A senha deve conter no mínimo 8 caracteres");
            }else
            if(txtConfirmacao.Text != txtSenha.Text)
            {
                msgAviso.Text = "As senhas não coincidem";
                txtConfirmacao.BorderColor = System.Drawing.Color.Red;
            }else
            if (txtConfirmacao.Text == txtSenha.Text)
            {
                SqlConnection conexao = new SqlConnection("Server = tcp:elly.database.windows.net,1433; Initial Catalog = elly; Persist Security Info = False; User ID = Elly; Password =Ellidy23; MultipleActiveResultSets = False; Encrypt = True; TrustServerCertificate = False; Connection Timeout = 30;");
                SqlCommand comandos = conexao.CreateCommand();
                using (conexao)
                {
                    conexao.Open();
                    comandos.CommandText = ($"insert into tbl_usuario values('{txtEmail.Text}', '{txtSenha.Text}', '{txtNome.Text}')");
                    SqlDataReader leitor = comandos.ExecuteReader();
                    msgAviso.Text = "Cadastrado com SUCESSO!";
                    txtConfirmacao.BorderColor = System.Drawing.Color.White;
                }
            }

        }
    }
}